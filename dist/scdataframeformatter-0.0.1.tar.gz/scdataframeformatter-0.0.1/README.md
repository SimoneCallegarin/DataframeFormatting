# DataframeFormatting
This is a tool that uses stylers in order to format pandas dataframes